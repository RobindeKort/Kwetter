package kwetter;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 *
 * @author Robin
 */
@ApplicationPath("/")
public class KwetterApplication extends Application {

}
