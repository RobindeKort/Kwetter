package domain;

/**
 *
 * @author Robin
 */
public enum Role {
    Administrator,
    Moderator,
    User
}
